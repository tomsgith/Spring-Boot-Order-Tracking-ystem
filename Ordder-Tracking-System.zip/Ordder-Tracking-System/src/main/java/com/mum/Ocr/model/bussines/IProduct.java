package com.mum.Ocr.model.bussines;

public interface IProduct {
	double getPrice();
}
