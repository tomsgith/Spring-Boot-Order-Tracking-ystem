package com.mum.Ocr.model.bussines;

public interface ICompPoints{
	double getPoints();
}
