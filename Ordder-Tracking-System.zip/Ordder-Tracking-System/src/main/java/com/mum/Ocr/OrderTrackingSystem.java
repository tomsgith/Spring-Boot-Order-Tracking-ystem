package com.mum.Ocr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderTrackingSystem{

	public static void main(String[] args) {
		SpringApplication.run(OrderTrackingSystem.class, args);
	}
}
