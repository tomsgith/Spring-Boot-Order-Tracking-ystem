package com.mum.Ocr.model.bussines;

public class OtherPoints extends ACompPoints{

	
	private final double points = 0.25;

	@Override
	public double getPoints() {
		return points;
	}

}
