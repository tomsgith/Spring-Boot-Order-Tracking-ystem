package com.mum.Ocr.model.bussines;

public class HealthPoints extends ACompPoints {

	
	private final double points=0.5;
	@Override
	public double getPoints() {
		return points;
	}

}
